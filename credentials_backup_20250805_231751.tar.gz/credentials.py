#!/usr/bin/env python3
"""
🔐 WOLFPACK-LITE CREDENTIALS
LIVE API KEYS - NEVER COMMIT TO GIT!
Replace with your actual keys before running.
"""

class WolfpackCredentials:
    """🔐 CENTRALIZED CREDENTIALS MANAGER - LIVE TRADING ONLY"""
    
    def __init__(self):
        print("🔐 LIVE TRADING CREDENTIALS LOADED")
        
    # ========== OANDA LIVE CREDENTIALS ==========
    OANDA_API_KEY = "2d33ea161ac49e4d5760c1c8653324d4-399737009e5af83934b8bce0489277cb"
    OANDA_ACCOUNT_ID = "001-001-13473069-001"
    OANDA_ENVIRONMENT = "live"  # LIVE TRADING ONLY
    OANDA_LIVE_URL = "https://api-fxtrade.oanda.com"  # LIVE ENDPOINT
    
    # ========== COINBASE ADVANCED TRADE LIVE CREDENTIALS ==========
    # JSON Credentials Format (Master ED25519 Protocol Compatible)
    # Source JSON: {"id": "2636c881-b44e-4263-b05d-fb10a5ad1836", "privateKey": "s+jUeS54GxpxQ3WOM5uLHHlm9JhCIrtBeE9X1Drn2IfPHg6yie2q+GEAIwRJGkAkZyUOgY0YQE27H1R5CNFGGg=="}
    
    # Primary Credentials (from JSON file)
    COINBASE_API_KEY_ID = "2636c881-b44e-4263-b05d-fb10a5ad1836"  # JSON "id" field
    COINBASE_PRIVATE_KEY = "s+jUeS54GxpxQ3WOM5uLHHlm9JhCIrtBeE9X1Drn2IfPHg6yie2q+GEAIwRJGkAkZyUOgY0YQE27H1R5CNFGGg=="  # JSON "privateKey" field (64 bytes)
    
    # Working ED25519 Formats (Extracted from above)
    COINBASE_PRIVATE_KEY_SEED = "s+jUeS54GxpxQ3WOM5uLHHlm9JhCIrtBeE9X1Drn2Ic="  # 32-byte ED25519 seed (base64)
    COINBASE_PRIVATE_KEY_HEX = "b3e8d4792e781b1a7143758e339b8b1c7966f4984222bb41784f57d43ae7d887"  # 32-byte seed (hex)
    COINBASE_PRIVATE_KEY_PEM = """-----BEGIN PRIVATE KEY-----
MC4CAQAwBQYDK2VwBCIEILPo1HkueBsacUN1jjObixx5ZvSYQiK7QXhPV9Q659iH
-----END PRIVATE KEY-----"""  # PEM format for JWT libraries
    
    # Legacy Format Support (for backwards compatibility)
    COINBASE_API_KEY = "2636c881-b44e-4263-b05d-fb10a5ad1836"  # Same as API_KEY_ID
    COINBASE_API_SECRET = "s+jUeS54GxpxQ3WOM5uLHHlm9JhCIrtBeE9X1Drn2IfPHg6yie2q+GEAIwRJGkAkZyUOgY0YQE27H1R5CNFGGg=="  # Same as PRIVATE_KEY
    
    # Endpoint Configuration
    COINBASE_LIVE_URL = "https://api.coinbase.com"  # Advanced Trade LIVE ENDPOINT
    COINBASE_CDP_URL = "https://api.cdp.coinbase.com"  # CDP LIVE ENDPOINT
    COINBASE_ALGO = "ed25519"  # ED25519 signature algorithm
    
    # Constitutional Compliance
    LIVE_TRADING_ONLY = True  # LIVE TRADING ONLY - NO SIMULATION
    
    # ========== BOT CONFIGURATION ==========
    # Capital & Risk Settings
    STARTING_CAPITAL = 3000  # Starting balance
    RISK_PER_TRADE = 1.0   # 1% risk per trade
    MAX_TRADES_PER_DAY = 10
    MAX_CONCURRENT_TRADES = 3
    
    # Trading Pairs
    OANDA_PAIRS = [
        "EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "USD/CAD",
        "USD/CHF", "NZD/USD", "EUR/GBP", "EUR/JPY", "GBP/JPY"
    ]
    
    COINBASE_PAIRS = [
        "BTC/USD", "ETH/USD", "SOL/USD", "ADA/USD", "XRP/USD",
        "DOGE/USD", "AVAX/USD", "DOT/USD", "MATIC/USD", "LINK/USD"
    ]
    
    # ========== SNIPER SETTINGS ==========
    # FVG Detection
    MIN_GAP_PERCENT = 0.15  # Minimum gap size as % of price
    MAX_FVG_AGE = 5        # Expire FVG after 5 candles
    
    # Risk Reward
    MIN_RISK_REWARD = 2.5     # Minimum 1:2.5 risk reward
    TARGET_RISK_REWARD = 3.0  # Target 1:3 risk reward
    
    # Confluence Requirements
    MIN_CONFLUENCE_SCORE = 7.0  # Minimum confluence score
    RSI_BULL_MIN = 35      # RSI < 35 for bullish FVG entry
    RSI_BEAR_MAX = 65      # RSI > 65 for bearish FVG entry
    
    # Scanning
    SCAN_INTERVAL = 2  # Seconds between scans
    
    # Position Scaling (Streak Logic)
    STREAK_SCALE_UP = {3: 1.25, 5: 1.4}    # Win streak multipliers
    STREAK_SCALE_DOWN = {2: 0.5}            # Loss streak reduction
    
    # ========== NOTIFICATION SETTINGS ==========
    # SMS & Alerts
    ALERT_PHONE_NUMBER = "+16099006119"
    ALERT_EMAIL = "+16099006119@tmomail.net"
    SMS_GATEWAY = "+16099006119@tmomail.net"
    USER_PHONE_NUMBER = "+16099906119"
    
    # Telegram
    TELEGRAM_CHAT_ID = "7546584370"
    TELEGRAM_BOT_TOKEN = "8168818486:AAE3I8NBCNh5gSHXitmyAn4QQT3qrCL8yY0"
    
    # Discord
    DISCORD_WEBHOOK_URL = "https://discord.com/api/webhooks/1366149105168158761/DdhePkvCJltPvpUisbvSI_pIvlBrmQ-ZLzc-IRii0wGV3ZbhKDlkQphTqReLnniAh8W8"
    
    # Constitutional Security
    CONSTITUTIONAL_PIN = "841921"
    
    # ========== WOLFPACK-PROTO ENHANCEMENTS ==========
    # Dynamic OCO Wave Riding
    WAVE_RIDE_THRESHOLD = 2.5  # Remove TP at this R:R for unlimited upside
    TRAIL_PERCENT = 0.0125     # 1.25% trailing distance below peak
    LOCK_MODE_THRESHOLD = 9.0  # Signal strength for no-TP pure trail mode
    
    # Market Psychology Quantification
    VOLUME_SURGE_MULTIPLIER = 2.0  # Volume must be >2x average for crypto signals
    GAP_SIZE_WEIGHT = 0.3          # Boost score by 0.3 for larger gaps (psych urgency)
    
    # Session-Aware Bias Dispatch
    BULL_SL_ADJUSTMENT = 1.005     # Wider SL in bull markets (room to climb)
    BEAR_SL_ADJUSTMENT = 0.995     # Tighter SL in bear markets (quick drops)
    
    # Arbitrage Engine
    MIN_ARBITRAGE_SPREAD = 0.15    # Minimum spread % for arbitrage
    ARBITRAGE_MIN_PROFIT = 20      # Minimum $20 profit for arbitrage execution
    
    # Heartbeat & Monitoring
    HEARTBEAT_INTERVAL = 15        # Guardian heartbeat every 15 seconds
    DASHBOARD_UPDATE_INTERVAL = 5  # Dashboard update frequency
    
    # Timezone Configuration
    TIMEZONE = "America/New_York"  # Hamilton, NJ (EST/EDT)
    
    def validate_credentials(self):
        """Validate that all credentials are properly configured"""
        issues = []
        
        # Check OANDA
        if not self.OANDA_API_KEY or "your-" in self.OANDA_API_KEY:
            issues.append("OANDA API key not properly set")
        if not self.OANDA_ACCOUNT_ID or "your-" in self.OANDA_ACCOUNT_ID:
            issues.append("OANDA account ID not properly set")
            
        # Check Coinbase
        if not self.COINBASE_API_KEY or "your-" in self.COINBASE_API_KEY:
            issues.append("Coinbase API key not properly set")
        if not self.COINBASE_API_SECRET or "your-" in self.COINBASE_API_SECRET:
            issues.append("Coinbase API secret not properly set")
            
        return issues
    
    def get_trading_summary(self):
        """Get summary of trading configuration"""
        return {
            "oanda_pairs": len(self.OANDA_PAIRS),
            "coinbase_pairs": len(self.COINBASE_PAIRS),
            "total_pairs": len(self.OANDA_PAIRS) + len(self.COINBASE_PAIRS),
            "risk_per_trade": f"{self.RISK_PER_TRADE}%",
            "min_rr": f"1:{self.MIN_RISK_REWARD}",
            "wave_ride_threshold": f"{self.WAVE_RIDE_THRESHOLD}R",
            "trail_percent": f"{self.TRAIL_PERCENT*100}%"
        }

#!/usr/bin/env python3
"""
🚀 LIVE ORDER EXECUTION DEMO - AUTO CONFIRM
Constitutional PIN: 841921
Automatically executes a minimal live order to prove the system works
"""

import logging

# HARDCODED LIVE CREDENTIALS
OANDA_API_KEY = "bfc61e32b5218b0b3fe258aa743a1ba8-557ab61dd7909d8407eeb0053bb98f48"
OANDA_ACCOUNT_ID = "001-001-13473069-001"

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')
logger = logging.getLogger(__name__)

def execute_live_order_auto():
    """Execute a minimal live order automatically"""
    logger.info("🚀 AUTO LIVE ORDER EXECUTION")
    logger.info("🚨 EXECUTING REAL MONEY ORDER - MINIMAL RISK")
    logger.info("=" * 50)
    
    try:
        import oandapyV20
        from oandapyV20 import API
        from oandapyV20.endpoints.orders import OrderCreate
        from oandapyV20.endpoints.pricing import PricingInfo
        from oandapyV20.endpoints.accounts import AccountDetails
        
        # Create hardcoded API connection
        api = API(
            access_token=OANDA_API_KEY,
            environment="live"  # HARDCODED LIVE
        )
        
        # Get account balance first
        account_request = AccountDetails(accountID=OANDA_ACCOUNT_ID)
        account_response = api.request(account_request)
        
        if account_response:
            balance = float(account_response['account']['balance'])
            logger.info(f"💰 Account Balance: ${balance:,.2f}")
        
        # Get current EUR/USD price
        pricing_request = PricingInfo(
            accountID=OANDA_ACCOUNT_ID,
            params={"instruments": "EUR_USD"}
        )
        pricing_response = api.request(pricing_request)
        
        if pricing_response and 'prices' in pricing_response:
            current_price = float(pricing_response['prices'][0]['closeoutBid'])
            logger.info(f"💱 Current EUR/USD: {current_price:.5f}")
            
            # Calculate conservative SL/TP
            sl_price = current_price - 0.0020  # 20 pip SL
            tp_price = current_price + 0.0060  # 60 pip TP
            
            # Create minimal risk order
            order_data = {
                "order": {
                    "instrument": "EUR_USD",
                    "units": "1",  # 1 unit = ~$1.16 position
                    "type": "MARKET",
                    "positionFill": "DEFAULT",
                    "stopLossOnFill": {"price": f"{sl_price:.5f}"},
                    "takeProfitOnFill": {"price": f"{tp_price:.5f}"}
                }
            }
            
            logger.info("📤 LIVE ORDER DETAILS:")
            logger.info(f"   Instrument: EUR_USD")
            logger.info(f"   Position Size: 1 unit (~${current_price:.2f})")
            logger.info(f"   Entry Price: ~{current_price:.5f}")
            logger.info(f"   Stop Loss: {sl_price:.5f} (-20 pips)")
            logger.info(f"   Take Profit: {tp_price:.5f} (+60 pips)")
            logger.info(f"   Max Risk: ~$2.00")
            logger.info(f"   Max Reward: ~$6.00")
            logger.info(f"   Risk/Reward: 1:3")
            logger.info("🚨 EXECUTING REAL MONEY ORDER NOW...")
            
            # Execute the order
            order_request = OrderCreate(accountID=OANDA_ACCOUNT_ID, data=order_data)
            response = api.request(order_request)
            
            logger.info(f"🔄 Order Response: {response}")
            
            if response and 'orderFillTransaction' in response:
                fill_data = response['orderFillTransaction']
                order_id = fill_data.get('id')
                trade_id = fill_data.get('tradeOpened', {}).get('tradeID') if 'tradeOpened' in fill_data else None
                fill_price = float(fill_data.get('price', current_price))
                
                logger.info("✅ LIVE ORDER EXECUTED SUCCESSFULLY!")
                logger.info(f"🎯 Order ID: {order_id}")
                if trade_id:
                    logger.info(f"🎯 Trade ID: {trade_id}")
                logger.info(f"🎯 Fill Price: {fill_price:.5f}")
                logger.info(f"🎯 Stop Loss: {sl_price:.5f}")
                logger.info(f"🎯 Take Profit: {tp_price:.5f}")
                logger.info("💰 REAL MONEY TRADE CONFIRMED")
                logger.info("🛡️  OCO PROTECTION ACTIVE")
                
                return {
                    'success': True,
                    'order_id': order_id,
                    'trade_id': trade_id,
                    'fill_price': fill_price,
                    'sl_price': sl_price,
                    'tp_price': tp_price
                }
            elif response and 'orderRejectTransaction' in response:
                reject_data = response['orderRejectTransaction']
                reason = reject_data.get('rejectReason', 'Unknown')
                logger.error(f"❌ Order rejected: {reason}")
                return {'success': False, 'error': f'Order rejected: {reason}'}
            else:
                logger.error("❌ Unexpected response format")
                return {'success': False, 'error': 'Unexpected response'}
                
        else:
            logger.error("❌ Failed to get current price")
            return {'success': False, 'error': 'Price fetch failed'}
            
    except Exception as e:
        logger.error(f"❌ Order execution failed: {e}")
        return {'success': False, 'error': str(e)}

def main():
    """Execute live order demo"""
    logger.info("🔥 HARDCODED LIVE ORDER EXECUTION - AUTO MODE")
    logger.info("Constitutional PIN: 841921")
    logger.info("Account: 001-001-13473069-001")
    logger.info("System: 100% Hardcoded Live Credentials")
    logger.info("")
    
    result = execute_live_order_auto()
    
    if result['success']:
        logger.info("\n🎉 LIVE ORDER EXECUTION SUCCESSFUL!")
        logger.info("✅ Hardcoded system works perfectly")
        logger.info("✅ Real money trading confirmed")
        logger.info("✅ OCO protection active")
        logger.info("✅ No simulation mode possible")
        logger.info("🚀 System ready for full live trading")
        
        logger.info(f"\n📊 TRADE SUMMARY:")
        logger.info(f"   Order ID: {result['order_id']}")
        if result.get('trade_id'):
            logger.info(f"   Trade ID: {result['trade_id']}")
        logger.info(f"   Fill Price: {result['fill_price']:.5f}")
        logger.info(f"   Stop Loss: {result['sl_price']:.5f}")
        logger.info(f"   Take Profit: {result['tp_price']:.5f}")
        
    else:
        logger.info(f"\n❌ Order execution failed: {result['error']}")
        logger.info("Check account status and market conditions")

if __name__ == "__main__":
    main()

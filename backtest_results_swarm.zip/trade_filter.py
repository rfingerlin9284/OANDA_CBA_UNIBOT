def is_trade_worthwhile(entry_price, target_profit, fees):
    return target_profit >= fees * 1.2

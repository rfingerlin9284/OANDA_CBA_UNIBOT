#!/usr/bin/env python3
"""
🎯 WOLFPACK-LITE LIVE TRADING SYSTEM
Constitutional PIN: 841921
100% LIVE TRADING ONLY - SIMULATION ELIMINATED

This is the primary live trading controller that:
1. Enforces live-only mode on startup
2. Connects to OANDA live API only
3. Executes real money trades with OCO protection
4. No simulation/practice mode logic whatsoever
"""

import os
import sys
import time
import json
import logging
import threading
from datetime import datetime
from typing import Dict, List
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# LIVE MODE ENFORCEMENT - Kill any simulation logic
os.environ['SIM_MODE'] = 'false'
os.environ['PRACTICE'] = 'false'
os.environ['SANDBOX_MODE'] = 'false'
os.environ['OANDA_ENVIRONMENT'] = 'live'
os.environ['TRADING_MODE'] = 'LIVE_ONLY'
os.environ['LIVE_TRADING_ONLY'] = 'true'

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/live_trading.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class WolfpackLiveTradingSystem:
    """100% Live Trading System - Constitutional PIN: 841921"""
    
    def __init__(self):
        self.constitutional_pin = "841921"
        self.start_time = datetime.now()
        self.is_running = False
        self.trade_count = 0
        self.total_pnl = 0.0
        
        # Verify live mode
        self.enforce_live_mode()
        
        # Initialize live credentials
        self.initialize_live_credentials()
        
        # Initialize OANDA live API
        self.initialize_oanda_live()
        
        logger.info("✅ WOLFPACK LIVE TRADING SYSTEM INITIALIZED")
        logger.info(f"🔐 Constitutional PIN: {self.constitutional_pin}")
        logger.info("🚨 LIVE TRADING ONLY - REAL MONEY AT RISK")
        
    def enforce_live_mode(self):
        """Enforce live-only trading mode"""
        logger.info("🚨 ENFORCING LIVE MODE...")
        
        # Check for any simulation mode indicators
        sim_indicators = [
            os.getenv('SIM_MODE', '').lower() == 'true',
            os.getenv('PRACTICE', '').lower() == 'true', 
            os.getenv('SANDBOX_MODE', '').lower() == 'true',
            os.getenv('OANDA_ENVIRONMENT', '').lower() in ['practice', 'demo', 'sandbox']
        ]
        
        if any(sim_indicators):
            logger.error("❌ SIMULATION MODE DETECTED - SYSTEM SHUTDOWN")
            logger.error("Constitutional violation - live trading only")
            sys.exit(1)
            
        # Verify live endpoints
        oanda_url = os.getenv('OANDA_API_URL', '')
        if 'fxpractice' in oanda_url:
            logger.error("❌ PRACTICE ENDPOINT DETECTED - SYSTEM SHUTDOWN")
            sys.exit(1)
            
        logger.info("✅ LIVE MODE ENFORCEMENT PASSED")
        
    def initialize_live_credentials(self):
        """Initialize live trading credentials"""
        logger.info("🔐 Initializing live credentials...")
        
        self.oanda_api_key = os.getenv('OANDA_API_KEY')
        self.oanda_account_id = os.getenv('OANDA_ACCOUNT_ID')
        self.oanda_environment = os.getenv('OANDA_ENVIRONMENT', 'live')
        self.oanda_url = os.getenv('OANDA_API_URL', 'https://api-fxtrade.oanda.com')
        
        if not self.oanda_api_key:
            logger.error("❌ OANDA API KEY missing")
            sys.exit(1)
            
        if not self.oanda_account_id:
            logger.error("❌ OANDA ACCOUNT ID missing")
            sys.exit(1)
            
        if self.oanda_environment != 'live':
            logger.error(f"❌ Non-live environment: {self.oanda_environment}")
            sys.exit(1)
            
        logger.info(f"✅ OANDA Live Account: {self.oanda_account_id}")
        logger.info(f"✅ OANDA Live URL: {self.oanda_url}")
        
    def initialize_oanda_live(self):
        """Initialize OANDA live API connection"""
        logger.info("🎯 Connecting to OANDA LIVE API...")
        
        try:
            import oandapyV20
            from oandapyV20 import API
            from oandapyV20.endpoints.accounts import AccountDetails
            
            # Create LIVE API connection - HARDCODED TO LIVE
            self.oanda_api = API(
                access_token=self.oanda_api_key,
                environment="live"  # HARDCODED - NEVER CHANGE
            )
            
            # Test connection with account details
            account_request = AccountDetails(accountID=self.oanda_account_id)
            response = self.oanda_api.request(account_request)
            
            if response:
                balance = float(response['account']['balance'])
                self.account_balance = balance
                logger.info(f"✅ OANDA LIVE CONNECTION VERIFIED")
                logger.info(f"💰 Account Balance: ${balance:,.2f}")
                logger.info(f"🔴 LIVE TRADING MODE CONFIRMED")
            else:
                logger.error("❌ Failed to verify OANDA live account")
                sys.exit(1)
                
        except Exception as e:
            logger.error(f"❌ OANDA live connection failed: {e}")
            sys.exit(1)
            
    def get_live_forex_pairs(self):
        """Get live forex pairs for trading"""
        return [
            "EUR_USD", "GBP_USD", "USD_JPY", "AUD_USD", "USD_CAD",
            "USD_CHF", "NZD_USD", "EUR_GBP", "EUR_JPY", "GBP_JPY"
        ]
        
    def get_recent_candles(self, pair: str, count: int = 30) -> List[Dict]:
        """Get recent candlestick data for strategy analysis"""
        try:
            from oandapyV20.endpoints.instruments import InstrumentsCandles
            
            # Convert pair format (EUR/USD -> EUR_USD)
            instrument = pair.replace('/', '_')
            
            # Request recent candles
            params = {
                "count": count,
                "granularity": "M5"  # 5-minute candles for FVG strategy
            }
            
            candles_request = InstrumentsCandles(instrument=instrument, params=params)
            response = self.oanda_api.request(candles_request)
            
            candles = []
            if response and 'candles' in response:
                for candle in response['candles']:
                    if candle['complete']:
                        candles.append({
                            'high': float(candle['mid']['h']),
                            'low': float(candle['mid']['l']),
                            'close': float(candle['mid']['c']),
                            'open': float(candle['mid']['o']),
                            'timestamp': candle['time']
                        })
            
            return candles
            
        except Exception as e:
            logger.error(f"❌ Failed to get candles for {pair}: {e}")
            return []

    def calculate_position_size(self, risk_amount=None):
        """Calculate position size for live trades"""
        if risk_amount is None:
            # Risk 3% of account balance per trade (increased from 1%)
            risk_amount = self.account_balance * 0.03
            
        logger.info(f"💱 Risk per trade: ${risk_amount:.2f}")
        return risk_amount
        
    def place_live_order(self, instrument, direction, entry_price, sl_price, tp_price):
        """Place a live order with OCO protection"""
        try:
            from oandapyV20.endpoints.orders import OrderCreate
            
            # Calculate position size
            risk_amount = self.calculate_position_size()
            
            # Calculate units based on risk
            pip_value = 0.0001 if "JPY" not in instrument else 0.01
            stop_distance = abs(entry_price - sl_price)
            units = int(risk_amount / stop_distance)
            
            if direction == "SELL":
                units = -units
                
            # Create order with OCO protection
            order_data = {
                "order": {
                    "instrument": instrument,
                    "units": str(units),
                    "type": "MARKET",
                    "positionFill": "DEFAULT",
                    "stopLossOnFill": {"price": str(sl_price)},
                    "takeProfitOnFill": {"price": str(tp_price)}
                }
            }
            
            logger.info(f"📤 PLACING LIVE ORDER:")
            logger.info(f"   Instrument: {instrument}")
            logger.info(f"   Direction: {direction}")
            logger.info(f"   Units: {units}")
            logger.info(f"   Entry: {entry_price}")
            logger.info(f"   Stop Loss: {sl_price}")
            logger.info(f"   Take Profit: {tp_price}")
            logger.info("🚨 REAL MONEY ORDER - EXECUTING NOW")
            
            # Execute live order
            order_request = OrderCreate(accountID=self.oanda_account_id, data=order_data)
            response = self.oanda_api.request(order_request)
            
            if response and 'orderFillTransaction' in response:
                fill_data = response['orderFillTransaction']
                order_id = fill_data.get('id')
                trade_id = fill_data.get('tradeOpened', {}).get('tradeID')
                fill_price = float(fill_data.get('price', entry_price))
                
                self.trade_count += 1
                
                logger.info("✅ LIVE ORDER EXECUTED SUCCESSFULLY")
                logger.info(f"   Order ID: {order_id}")
                logger.info(f"   Trade ID: {trade_id}")
                logger.info(f"   Fill Price: {fill_price}")
                logger.info("🎯 OCO protection active")
                
                return {
                    'success': True,
                    'order_id': order_id,
                    'trade_id': trade_id,
                    'fill_price': fill_price,
                    'instrument': instrument,
                    'units': units
                }
            else:
                logger.error("❌ Order execution failed - no fill transaction")
                return {'success': False, 'error': 'No fill transaction'}
                
        except Exception as e:
            logger.error(f"❌ Live order failed: {e}")
            return {'success': False, 'error': str(e)}
            
    def scan_for_trading_opportunities(self):
        """Scan for live trading opportunities"""
        logger.info("🔍 Scanning for live trading opportunities...")
        
        pairs = self.get_live_forex_pairs()
        
        for pair in pairs:
            try:
                # Get current market price
                from oandapyV20.endpoints.pricing import PricingInfo
                
                pricing_request = PricingInfo(accountID=self.oanda_account_id, params={"instruments": pair})
                pricing_response = self.oanda_api.request(pricing_request)
                
                if pricing_response and 'prices' in pricing_response:
                    price_data = pricing_response['prices'][0]
                    current_price = float(price_data['closeoutBid'])
                    
                    # === REAL FVG STRATEGY INTEGRATION ===
                    from fvg_strategy import FVGStrategy
                    
                    try:
                        # Initialize FVG strategy
                        fvg_strategy = FVGStrategy()
                        
                        # Get recent candlestick data for FVG analysis
                        candles = self.get_recent_candles(pair, 30)  # Get 30 recent candles
                        
                        if candles and len(candles) >= 25:
                            # Scan for FVG signals using real strategy
                            signal = fvg_strategy.scan_for_signals(candles, pair)
                            
                            if signal and fvg_strategy.validate_setup(signal):
                                # Execute FVG-based trade with real logic
                                direction = signal['direction']
                                entry_price = signal['entry']
                                sl_price = signal['sl']
                                tp_price = signal['tp']
                                
                                logger.info(f"🎯 FVG SIGNAL DETECTED!")
                                logger.info(f"   Pair: {pair}")
                                logger.info(f"   Setup: {signal['setup_type']}")
                                logger.info(f"   Confidence: {signal['confidence']}")
                                logger.info(f"   Gap Size: {signal['gap_size']}%")
                                
                                # Execute live trade with FVG parameters
                                result = self.place_live_order(pair, direction, current_price, sl_price, tp_price)
                                
                                if result['success']:
                                    logger.info(f"✅ FVG TRADE EXECUTED: {direction} {pair}")
                                    trades_placed += 1
                                else:
                                    logger.error(f"❌ FVG trade failed: {result['error']}")
                            else:
                                logger.debug(f"📊 No valid FVG signal for {pair}")
                        else:
                            logger.debug(f"📊 Insufficient candle data for {pair} FVG analysis")
                            
                    except Exception as e:
                        logger.error(f"❌ FVG strategy error for {pair}: {e}")
                        # Log price for monitoring but don't place random trades
                        logger.info(f"📊 {pair}: ${current_price:.5f} (monitoring only)")
                        
                    # FVG strategy replaces all random trading logic
                
            except Exception as e:
                logger.error(f"❌ Error scanning {pair}: {e}")
                
    def trading_loop(self):
        """Main live trading loop"""
        logger.info("🚀 STARTING LIVE TRADING LOOP")
        logger.info("🚨 REAL MONEY TRADING - CONSTITUTIONAL PIN: 841921")
        
        while self.is_running:
            try:
                # Update account balance
                self.update_account_balance()
                
                # Scan for opportunities
                self.scan_for_trading_opportunities()
                
                # System status
                uptime = (datetime.now() - self.start_time).total_seconds() / 60
                logger.info(f"💓 LIVE SYSTEM HEARTBEAT - Uptime: {uptime:.1f}m, Trades: {self.trade_count}")
                
                # Sleep between scans
                time.sleep(30)  # Scan every 30 seconds
                
            except KeyboardInterrupt:
                logger.info("🛑 Keyboard interrupt - stopping trading")
                break
            except Exception as e:
                logger.error(f"❌ Trading loop error: {e}")
                time.sleep(10)
                
    def update_account_balance(self):
        """Update current account balance"""
        try:
            from oandapyV20.endpoints.accounts import AccountDetails
            
            account_request = AccountDetails(accountID=self.oanda_account_id)
            response = self.oanda_api.request(account_request)
            
            if response:
                self.account_balance = float(response['account']['balance'])
                unrealized_pnl = float(response['account']['unrealizedPL'])
                self.total_pnl = float(response['account']['pl'])
                
                logger.info(f"💰 Balance: ${self.account_balance:,.2f} | "
                          f"Unrealized PnL: ${unrealized_pnl:,.2f} | "
                          f"Total PnL: ${self.total_pnl:,.2f}")
                
        except Exception as e:
            logger.error(f"❌ Failed to update balance: {e}")
            
    def start(self):
        """Start the live trading system"""
        logger.info("🚀 STARTING WOLFPACK LIVE TRADING SYSTEM")
        logger.info("=" * 60)
        logger.info("⚠️  WARNING: LIVE TRADING WITH REAL MONEY")
        logger.info("🔐 Constitutional PIN: 841921")
        logger.info("🎯 Live Trading Only - No Simulation Mode")
        logger.info("=" * 60)
        
        # Final confirmation for live trading
        print("\n🚨 FINAL WARNING: This will trade with REAL MONEY on OANDA live account")
        print(f"💰 Account Balance: ${self.account_balance:,.2f}")
        print("🔴 Live Trading Mode Confirmed")
        
        confirm = input("\nType 'LIVE TRADING CONFIRMED' to proceed: ").strip()
        if confirm != "LIVE TRADING CONFIRMED":
            logger.info("❌ Live trading not confirmed - system shutdown")
            return
            
        self.is_running = True
        
        # Start trading in separate thread
        trading_thread = threading.Thread(target=self.trading_loop, daemon=True)
        trading_thread.start()
        
        logger.info("✅ LIVE TRADING SYSTEM ACTIVE")
        
        try:
            while self.is_running:
                time.sleep(1)
        except KeyboardInterrupt:
            logger.info("🛑 Stopping live trading system")
            self.is_running = False
            
        logger.info("✅ Live trading system stopped")
        runtime = (datetime.now() - self.start_time).total_seconds() / 60
        logger.info(f"📊 Session Summary:")
        logger.info(f"   Runtime: {runtime:.1f} minutes")
        logger.info(f"   Trades Executed: {self.trade_count}")
        logger.info(f"   Total PnL: ${self.total_pnl:.2f}")

def main():
    """Main entry point"""
    # Create logs directory
    os.makedirs('logs', exist_ok=True)
    
    # Initialize and start live trading system
    trading_system = WolfpackLiveTradingSystem()
    trading_system.start()

if __name__ == "__main__":
    main()

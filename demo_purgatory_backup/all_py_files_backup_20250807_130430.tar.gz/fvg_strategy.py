"""
FAIR VALUE GAP (FVG) STRATEGY - EXPLICIT RULES & PARAMETERS
LIVE TRADING ONLY - REAL MONEY AT RISK

Strategy Rules:
- Timeframe: 5-minute and 15-minute candles
- Bullish FVG: Candle1.high < Candle3.low AND Candle2.close < Candle3.close
- Bearish FVG: Candle1.low > Candle3.high AND Candle2.close > Candle3.close
- Gap Threshold: Must be ≥ 0.2% of asset price
- Entry: Mid-gap = (Candle1.extreme + Candle3.extreme) / 2
- Stop Loss: Candle1.extreme (opposite side)
- Take Profit: 1:3 Risk-Reward ratio minimum
- Min Confidence: 0.80 (FVG + Fib + Indicators)
- Max Trades per Pair: 1 (no doubling down)
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
import talib


class FVGStrategy:
    """Fair Value Gap Strategy with Explicit Rules"""
    
    def __init__(self):
        # === STRATEGY PARAMETERS (EXPLICITLY DEFINED) ===
        self.FVG_GAP_THRESHOLD = 0.002  # 0.2% minimum gap size
        self.MIN_CONFIDENCE = 0.80      # 80% minimum confidence
        self.RISK_REWARD_RATIO = 3.0    # 1:3 RR minimum
        self.ATR_VOLATILITY_MIN = 0.005 # 0.5% minimum ATR
        self.FIBONACCI_LEVELS = [0.618, 0.786]  # Key fib retracement levels
        self.SETUP_EXPIRY_CANDLES = 3   # Setup expires after 3 candles
        
        # === INDICATOR PERIODS ===
        self.EMA_PERIOD = 21
        self.RSI_PERIOD = 14
        self.ATR_PERIOD = 14
        
        print("🎯 FVG Strategy initialized with explicit rules")
        print(f"📊 Gap threshold: {self.FVG_GAP_THRESHOLD*100}%")
        print(f"🎯 Min confidence: {self.MIN_CONFIDENCE}")
        print(f"💰 Risk:Reward = 1:{self.RISK_REWARD_RATIO}")
    
    def detect_bullish_fvg(self, candles: List[Dict]) -> Optional[Dict]:
        """
        BULLISH FVG DETECTION - EXPLICIT RULES
        
        Rule: Candle1.high < Candle3.low AND Candle2.close < Candle3.close
        Entry: Mid-gap between Candle1.high and Candle3.low
        SL: Candle1.low
        TP: Entry + (Entry - SL) * RR_RATIO
        """
        if len(candles) < 3:
            return None
            
        # Get last 3 candles (most recent = index 2)
        candle1 = candles[-3]  # Oldest
        candle2 = candles[-2]  # Middle  
        candle3 = candles[-1]  # Most recent
        
        # === BULLISH FVG RULE CHECK ===
        condition1 = candle1['high'] < candle3['low']
        condition2 = candle2['close'] < candle3['close']
        
        if not (condition1 and condition2):
            return None
            
        # === GAP SIZE VALIDATION ===
        gap_size = candle3['low'] - candle1['high']
        gap_percentage = gap_size / candle3['low']
        
        if gap_percentage < self.FVG_GAP_THRESHOLD:
            return None
            
        # === CALCULATE ENTRY/SL/TP ===
        entry = (candle1['high'] + candle3['low']) / 2  # Mid-gap entry
        sl = candle1['low']  # Below the gap
        risk = entry - sl
        tp = entry + (risk * self.RISK_REWARD_RATIO)  # 1:3 RR
        
        return {
            'direction': 'BUY',
            'entry': round(entry, 5),
            'sl': round(sl, 5),
            'tp': round(tp, 5),
            'gap_size': round(gap_percentage * 100, 2),
            'risk': round(risk, 5),
            'reward': round(risk * self.RISK_REWARD_RATIO, 5),
            'setup_type': 'Bullish FVG',
            'candle1_high': candle1['high'],
            'candle3_low': candle3['low']
        }
    
    def detect_bearish_fvg(self, candles: List[Dict]) -> Optional[Dict]:
        """
        BEARISH FVG DETECTION - EXPLICIT RULES
        
        Rule: Candle1.low > Candle3.high AND Candle2.close > Candle3.close
        Entry: Mid-gap between Candle1.low and Candle3.high
        SL: Candle1.high
        TP: Entry - (SL - Entry) * RR_RATIO
        """
        if len(candles) < 3:
            return None
            
        # Get last 3 candles (most recent = index 2)
        candle1 = candles[-3]  # Oldest
        candle2 = candles[-2]  # Middle
        candle3 = candles[-1]  # Most recent
        
        # === BEARISH FVG RULE CHECK ===
        condition1 = candle1['low'] > candle3['high']
        condition2 = candle2['close'] > candle3['close']
        
        if not (condition1 and condition2):
            return None
            
        # === GAP SIZE VALIDATION ===
        gap_size = candle1['low'] - candle3['high']
        gap_percentage = gap_size / candle3['high']
        
        if gap_percentage < self.FVG_GAP_THRESHOLD:
            return None
            
        # === CALCULATE ENTRY/SL/TP ===
        entry = (candle1['low'] + candle3['high']) / 2  # Mid-gap entry
        sl = candle1['high']  # Above the gap
        risk = sl - entry
        tp = entry - (risk * self.RISK_REWARD_RATIO)  # 1:3 RR
        
        return {
            'direction': 'SELL',
            'entry': round(entry, 5),
            'sl': round(sl, 5),
            'tp': round(tp, 5),
            'gap_size': round(gap_percentage * 100, 2),
            'risk': round(risk, 5),
            'reward': round(risk * self.RISK_REWARD_RATIO, 5),
            'setup_type': 'Bearish FVG',
            'candle1_low': candle1['low'],
            'candle3_high': candle3['high']
        }
    
    def calculate_indicators(self, candles: List[Dict]) -> Dict:
        """Calculate confluence indicators"""
        if len(candles) < max(self.EMA_PERIOD, self.RSI_PERIOD, self.ATR_PERIOD):
            return {}
            
        # Convert to arrays for talib
        closes = np.array([c['close'] for c in candles])
        highs = np.array([c['high'] for c in candles])
        lows = np.array([c['low'] for c in candles])
        
        # Calculate indicators
        ema = talib.EMA(closes, timeperiod=self.EMA_PERIOD)
        rsi = talib.RSI(closes, timeperiod=self.RSI_PERIOD)
        atr = talib.ATR(highs, lows, closes, timeperiod=self.ATR_PERIOD)
        
        current_price = closes[-1]
        
        return {
            'ema': ema[-1] if not np.isnan(ema[-1]) else None,
            'rsi': rsi[-1] if not np.isnan(rsi[-1]) else None,
            'atr': atr[-1] if not np.isnan(atr[-1]) else None,
            'atr_percentage': (atr[-1] / current_price) if not np.isnan(atr[-1]) else None,
            'price_above_ema': current_price > ema[-1] if not np.isnan(ema[-1]) else None,
            'rsi_bullish': rsi[-1] > 50 if not np.isnan(rsi[-1]) else None
        }
    
    def check_fibonacci_confluence(self, candles: List[Dict], setup: Dict) -> bool:
        """Check if setup respects key Fibonacci levels"""
        if len(candles) < 20:
            return True  # Skip fib check if not enough data
            
        # Get recent swing high/low for fib calculation
        highs = [c['high'] for c in candles[-20:]]
        lows = [c['low'] for c in candles[-20:]]
        
        swing_high = max(highs)
        swing_low = min(lows)
        
        fib_range = swing_high - swing_low
        
        # Calculate key fib levels
        fib_618 = swing_high - (fib_range * 0.618)
        fib_786 = swing_high - (fib_range * 0.786)
        
        entry = setup['entry']
        
        # Check if entry is near key fib levels (within 0.1% tolerance)
        tolerance = entry * 0.001
        
        near_618 = abs(entry - fib_618) <= tolerance
        near_786 = abs(entry - fib_786) <= tolerance
        
        return near_618 or near_786
    
    def calculate_confidence(self, setup: Dict, indicators: Dict, fib_confluence: bool) -> float:
        """
        CONFIDENCE CALCULATION - EXPLICIT SCORING
        
        Base: 0.5 (50% for valid FVG)
        + 0.1 if gap size > 0.3%
        + 0.1 if RSI confirms direction
        + 0.1 if EMA confirms direction  
        + 0.1 if ATR shows good volatility
        + 0.1 if Fibonacci confluence
        
        Max: 1.0 (100%)
        """
        confidence = 0.5  # Base score for valid FVG
        
        # Gap size bonus
        if setup['gap_size'] > 0.3:  # > 0.3%
            confidence += 0.1
            
        # RSI confluence
        if indicators.get('rsi') is not None:
            if setup['direction'] == 'BUY' and indicators['rsi_bullish']:
                confidence += 0.1
            elif setup['direction'] == 'SELL' and not indicators['rsi_bullish']:
                confidence += 0.1
                
        # EMA confluence
        if indicators.get('price_above_ema') is not None:
            if setup['direction'] == 'BUY' and indicators['price_above_ema']:
                confidence += 0.1
            elif setup['direction'] == 'SELL' and not indicators['price_above_ema']:
                confidence += 0.1
                
        # ATR volatility check
        if indicators.get('atr_percentage') is not None:
            if indicators['atr_percentage'] >= self.ATR_VOLATILITY_MIN:
                confidence += 0.1
                
        # Fibonacci confluence
        if fib_confluence:
            confidence += 0.1
            
        return min(confidence, 1.0)  # Cap at 100%
    
    def scan_for_signals(self, candles: List[Dict], pair: str) -> Optional[Dict]:
        """
        MAIN SIGNAL SCANNER - SCANS FOR BOTH BULLISH & BEARISH FVG
        
        Returns complete signal with all parameters if confidence >= threshold
        """
        if len(candles) < 25:  # Need enough data for indicators
            return None
            
        # Calculate indicators first
        indicators = self.calculate_indicators(candles)
        
        # Check for bullish FVG
        bullish_setup = self.detect_bullish_fvg(candles)
        if bullish_setup:
            fib_confluence = self.check_fibonacci_confluence(candles, bullish_setup)
            confidence = self.calculate_confidence(bullish_setup, indicators, fib_confluence)
            
            if confidence >= self.MIN_CONFIDENCE:
                return {
                    **bullish_setup,
                    'pair': pair,
                    'confidence': round(confidence, 2),
                    'indicators': indicators,
                    'fib_confluence': fib_confluence,
                    'timestamp': candles[-1].get('timestamp', 0),
                    'signal_type': 'FVG_BULLISH'
                }
        
        # Check for bearish FVG
        bearish_setup = self.detect_bearish_fvg(candles)
        if bearish_setup:
            fib_confluence = self.check_fibonacci_confluence(candles, bearish_setup)
            confidence = self.calculate_confidence(bearish_setup, indicators, fib_confluence)
            
            if confidence >= self.MIN_CONFIDENCE:
                return {
                    **bearish_setup,
                    'pair': pair,
                    'confidence': round(confidence, 2),
                    'indicators': indicators,
                    'fib_confluence': fib_confluence,
                    'timestamp': candles[-1].get('timestamp', 0),
                    'signal_type': 'FVG_BEARISH'
                }
        
        return None
    
    def validate_setup(self, signal: Dict) -> bool:
        """Final validation before trade execution"""
        
        # Check risk-reward ratio
        risk = signal['risk']
        reward = signal['reward']
        
        if reward / risk < self.RISK_REWARD_RATIO * 0.9:  # Allow 10% tolerance
            return False
            
        # Check gap size is meaningful
        if signal['gap_size'] < self.FVG_GAP_THRESHOLD * 100:
            return False
            
        # Check confidence is above threshold
        if signal['confidence'] < self.MIN_CONFIDENCE:
            return False
            
        return True


# === TESTING FUNCTION ===
def test_fvg_strategy():
    """Test FVG strategy with sample data"""
    strategy = FVGStrategy()
    
    # Sample bullish FVG data
    sample_candles = [
        {'high': 1.1000, 'low': 1.0980, 'close': 1.0990, 'timestamp': 1620000000},
        {'high': 1.1010, 'low': 1.0985, 'close': 1.0995, 'timestamp': 1620000300},
        {'high': 1.1030, 'low': 1.1015, 'close': 1.1025, 'timestamp': 1620000600},  # Gap created
    ]
    
    # Add more candles for indicators
    for i in range(22):
        sample_candles.insert(0, {
            'high': 1.0950 + (i * 0.001),
            'low': 1.0940 + (i * 0.001), 
            'close': 1.0945 + (i * 0.001),
            'timestamp': 1620000000 - ((22-i) * 300)
        })
    
    signal = strategy.scan_for_signals(sample_candles, "EUR/USD")
    
    if signal:
        print("✅ FVG Signal Detected:")
        print(f"  Direction: {signal['direction']}")
        print(f"  Entry: {signal['entry']}")
        print(f"  SL: {signal['sl']}")
        print(f"  TP: {signal['tp']}")
        print(f"  Confidence: {signal['confidence']}")
        print(f"  Gap Size: {signal['gap_size']}%")
    else:
        print("❌ No FVG signal detected")


if __name__ == "__main__":
    test_fvg_strategy()

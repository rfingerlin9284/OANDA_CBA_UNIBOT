import os
import pandas as pd
import numpy as np
from joblib import load

DATA_DIR = "data/oanda"
MODELS_DIR = "models"
MODELS = ["wolfpack_ml_latest.pkl", "light_heavy_model.pkl"]

# 🔍 Collect required features from all models
required_features = set()
for model_name in MODELS:
    try:
        model_path = os.path.join(MODELS_DIR, model_name)
        model = load(model_path)
        if hasattr(model, "feature_names_in_"):
            required_features.update(model.feature_names_in_)
        elif hasattr(model, "get_booster"):
            booster = model.get_booster()
            required_features.update(booster.feature_names)
    except Exception as e:
        print(f"⚠️ Warning: Failed to inspect model {model_name}: {e}")

def session_bias(df):
    hours = pd.to_datetime(df['timestamp']).dt.hour
    bias = np.full(len(df), "OFF", dtype=object)
    bias[(hours >= 2) & (hours <= 11)] = "ASIA"
    bias[(hours >= 7) & (hours <= 16)] = "LONDON"
    bias[(hours >= 13) & (hours <= 22)] = "NEWYORK"
    return bias

def ema_cross(df, fast=5, slow=15):
    ema_fast = df['close'].ewm(span=fast).mean()
    ema_slow = df['close'].ewm(span=slow).mean()
    return (ema_fast > ema_slow).astype(int)

def estimate_fvg_strength(df):
    diff1 = abs(df['open'] - df['close'].shift(1))
    diff2 = abs(df['low'] - df['high'].shift(1))
    return (diff1 + diff2) / df['close']

def simple_rsi(df, period=14):
    delta = df['close'].diff()
    gain = delta.clip(lower=0).rolling(period).mean()
    loss = -delta.clip(upper=0).rolling(period).mean()
    rs = gain / (loss + 1e-9)
    return 100 - (100 / (1 + rs))

def volume_ratio(df):
    return df['volume'] / df['volume'].rolling(5).mean()

def estimate_order_imbalance(df):
    buy_pressure = df['close'] - df['low']
    sell_pressure = df['high'] - df['close']
    return (buy_pressure - sell_pressure) / (df['high'] - df['low'] + 1e-9)

def add_all_features(df):
    df = df.copy()
    df['ema_cross'] = ema_cross(df)
    df['fvg_strength'] = estimate_fvg_strength(df)
    df['rsi'] = simple_rsi(df)
    df['volume_ratio'] = volume_ratio(df)
    df['session_bias'] = session_bias(df)
    df['oanda_order_imbalance'] = estimate_order_imbalance(df)
    df['coinbase_order_imbalance'] = estimate_order_imbalance(df)  # Reuse logic
    df.dropna(inplace=True)
    return df

for file in os.listdir(DATA_DIR):
    if file.endswith("_features.csv"):
        path = os.path.join(DATA_DIR, file)
        try:
            df = pd.read_csv(path)
            df = add_all_features(df)
            missing = required_features - set(df.columns)
            if missing:
                print(f"❌ {file} missing: {missing}")
            else:
                df.to_csv(path, index=False)
                print(f"✅ Features updated: {file}")
        except Exception as e:
            print(f"❌ Failed on {file}: {e}")

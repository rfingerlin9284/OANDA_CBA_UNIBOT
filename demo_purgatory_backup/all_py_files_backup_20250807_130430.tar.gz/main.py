import os, sys, time, datetime, threading, random, psutil

# Color codes for Bash
def color(msg, col):
    codes = {
        "green": "\033[92m", "red": "\033[91m", "yellow": "\033[93m",
        "blue": "\033[94m", "magenta": "\033[95m", "cyan": "\033[96m",
        "grey": "\033[90m", "reset": "\033[0m"
    }
    return f"{codes.get(col,'')}{msg}{codes['reset']}"

def print_feed(msg, col="green"):
    print(color(msg, col))
    os.makedirs("logs", exist_ok=True)
    with open("logs/clean_ml_stream.log", "a") as f:
        f.write(f"{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | {msg}\n")

def get_open_positions():
    # Replace this with actual trading logic; here’s a fake example
    return [
        {"platform": "OANDA", "order_id": 21003, "oco_id": "21003_OCO", "symbol": "EUR/USD", "side": "BUY", "status": "open", "sl": 1.1234, "tp": 1.1315, "pnl": 37.24},
        {"platform": "COINBASE", "order_id": 88921, "oco_id": "88921_OCO", "symbol": "BTC/USD", "side": "SELL", "status": "open", "sl": 42990, "tp": 41100, "pnl": -70.14}
    ]

def get_mini_bots():
    # Fake assignments; replace with your actual logic
    return [
        {"bot": 1, "assigned_order": 21003, "pair": "EUR/USD", "desc": "Strong bullish move. Trailing SL enabled.", "status": "ACTIVE"},
        {"bot": 2, "assigned_order": 88921, "pair": "BTC/USD", "desc": "Short, volatility up. TP static, OCO linked.", "status": "ACTIVE"}
    ]

def commander_loop():
    start = time.time()
    uptime = lambda: (time.time() - start) / 60

    while True:
        cpu = psutil.cpu_percent(interval=0.1)
        mem = psutil.virtual_memory().percent

        print_feed(f"HEARTBEAT | ALL SYSTEMS GO | UPTIME: {uptime():.1f}m | CPU: {cpu:.0f}% | MEM: {mem:.0f}%", "cyan")

        # --- Open Positions ---
        ops = get_open_positions()
        if ops:
            print_feed(f"Current Open Positions:", "yellow")
            for o in ops:
                s = f"  [{o['platform']}] {o['symbol']} | #{o['order_id']} / OCO: {o['oco_id']} | Side: {o['side']} | SL: {o['sl']} | TP: {o['tp']} | PnL: ${o['pnl']:.2f}"
                print_feed(s, "yellow")
        else:
            print_feed("No open positions.", "grey")

        # --- Active Mini Bots ---
        bots = get_mini_bots()
        if bots:
            print_feed("Active Mini Bots:", "magenta")
            for b in bots:
                msg = f"  MiniBot#{b['bot']} → [{b['pair']}] (Order {b['assigned_order']}): {b['desc']}"
                print_feed(msg, "magenta")
        else:
            print_feed("No active mini-bots.", "grey")

        # --- Suggestions & Actions ---
        print_feed("SUGGESTIONS:", "blue")
        print_feed("  - Monitor volatility: OANDA EUR/USD trending strong.", "blue")
        print_feed("  - System ready. All bots synced.", "blue")

        # --- Alert Examples ---
        if random.randint(1, 10) == 3:
            print_feed("[⚠️] WARNING: OANDA connection unstable. Reconnecting...", "red")
        if random.randint(1, 15) == 6:
            print_feed("[!] MiniBot#2 lost signal—auto-recovering.", "red")

        # Sleep between each commander output loop (5s)
        time.sleep(5)

if __name__ == "__main__":
    print_feed("=== RBOTzilla UNIVERSAL BOOT ===", "green")
    print_feed("[✓] OANDA API: CONNECTED", "cyan")
    print_feed("[✓] Coinbase API: CONNECTED", "cyan")
    print_feed("[✓] ML Engine: CONNECTED", "cyan")
    print_feed("[✓] Order Router: CONNECTED", "cyan")
    print_feed("[✓] Strategy Core: CONNECTED", "cyan")
    print_feed("[✓] Dashboard Relay: CONNECTED", "cyan")
    print_feed("[✓] Commander Feed: CONNECTED", "cyan")
    print_feed("Checking internal relays, health status, and system readiness...", "yellow")
    print_feed("System Diagnostics: PASS | All modules synchronized & online.", "green")
    threading.Thread(target=commander_loop, daemon=True).start()
    while True:
        time.sleep(60)  # Just to keep main thread alive


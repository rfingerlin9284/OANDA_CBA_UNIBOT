#!/usr/bin/env python3
"""
🧠 RBOTZILLA SWARM TELEMETRY LOGGER
Constitutional PIN: 841921
Thread-safe, type-coerced, JSON-validated logging
"""
import json
import os
import threading
from datetime import datetime
from typing import Any, Union

class RBotZillaTelemetry:
    """RBOTZILLA Swarm telemetry logger with thread safety"""
    
    def __init__(self):
        self.lock = threading.Lock()
        self.log_file = "logs/ml_predictions.log"
        self.dashboard_file = "dashboard/static/js/telemetry.json"
        
    def log_telemetry(self, prediction: Any, confidence: Union[float, str], model_name: str = "WolfNet-V3"):
        """Thread-safe telemetry logging with type coercion"""
        try:
            with self.lock:
                # Type coercion and validation
                payload = {
                    "timestamp": datetime.utcnow().isoformat() + "Z",
                    "constitutional_pin": "841921",
                    "prediction": str(prediction).upper() if prediction else "UNKNOWN",
                    "confidence": round(float(confidence) if confidence else 0.0, 4),
                    "model": str(model_name),
                    "system": "RBOTZILLA_SWARM"
                }
                
                # Log to file
                with open(self.log_file, "a") as f:
                    f.write("ML DECISION: " + json.dumps(payload, separators=(',', ':')) + "\n")
                
                # Update dashboard (last 10 entries)
                self._update_dashboard()
                
        except Exception as e:
            # Fallback logging
            with open("logs/telemetry_errors.log", "a") as f:
                f.write(f"TELEMETRY ERROR: {datetime.utcnow().isoformat()}: {e}\n")
    
    def _update_dashboard(self):
        """Update dashboard telemetry JSON"""
        try:
            # Read last 10 entries
            entries = []
            if os.path.exists(self.log_file):
                with open(self.log_file, "r") as f:
                    lines = f.readlines()[-10:]  # Last 10 entries
                    for line in lines:
                        if "ML DECISION:" in line:
                            json_str = line.split("ML DECISION:", 1)[1].strip()
                            entries.append(json.loads(json_str))
            
            # Write to dashboard
            with open(self.dashboard_file, "w") as f:
                json.dump({"telemetry": entries}, f, indent=2)
                
        except Exception as e:
            pass  # Silent fail for dashboard update

# Global instance
RBOTZILLA_TELEMETRY = RBotZillaTelemetry()

def log_telemetry(prediction, confidence, model_name="WolfNet-V3"):
    """Global function for easy access"""
    RBOTZILLA_TELEMETRY.log_telemetry(prediction, confidence, model_name)

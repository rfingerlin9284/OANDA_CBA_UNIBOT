FEATURE_COLUMNS = [
    "RSI", "FVG", "VolumeDelta", "Bias", "PriceChange",
    "FVGWidth", "IsBreakout", "OrderBookPressure"
]

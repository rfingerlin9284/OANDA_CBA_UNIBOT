#!/usr/bin/env python3
"""
🧠 WOLFPACK-PROTO SNIPER CORE
Enhanced FVG detection with mass psychology quantification
Quantifies herd behavior: FVG gaps as institutional imbalances, RSI for overreactions,
volume surges for breakout frenzies, Fib zones for exhaustion, EMA for trend alignment
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import ta
from logger import logger, log_trade, log_error

class FVGSniper:
    """🎯 ENHANCED FVG SNIPER - Mass Psychology Quantifier"""
    
    def __init__(self):
        self.min_fvg_size = 0.0001  # Minimum FVG size (1 pip for forex)
        self.max_fvg_age = 24  # Max hours before FVG expires
        self.volume_lookback = 20  # Volume average lookback
        
    def scan_for_signals(self, candles_data, symbol, platform="coinbase", bias="neutral"):
        """
        🔍 ENHANCED SIGNAL SCANNING WITH MASS PSYCHOLOGY
        Returns signal dict with psychology scoring or None
        """
        try:
            # Convert candles to DataFrame
            df = self.prepare_dataframe(candles_data)
            
            if len(df) < 50:
                return None
            
            # Detect FVG with psychology awareness
            fvg_data = self.detect_fvg_with_psychology(df, platform)
            if not fvg_data:
                return None
            
            # Calculate enhanced confluence with market-aware scoring
            confluence_score = self.validate_entry_confluence_enhanced(df, fvg_data, platform, bias)
            
            if confluence_score >= 7.0:  # Enhanced minimum confluence
                signal = {
                    'symbol': symbol,
                    'type': fvg_data['type'],
                    'signal_strength': confluence_score,
                    'entry_price': fvg_data['midpoint'],
                    'fvg_data': fvg_data,
                    'timestamp': datetime.utcnow(),
                    'rsi': df['rsi'].iloc[-1] if 'rsi' in df.columns else 50,
                    'volume_surge': fvg_data.get('volume_surge', False),
                    'gap_psychology_score': fvg_data.get('psychology_score', 0),
                    'platform': platform,
                    'bias': bias
                }
                return signal
            
            return None
            
        except Exception as e:
            log_error(f"Enhanced signal scan error: {e}", "SIGNAL_SCAN")
            return None
    
    def prepare_dataframe(self, candles_data):
        """Convert OHLCV data to DataFrame with enhanced indicators"""
        df = pd.DataFrame(candles_data, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
        
        # Technical indicators for mass psychology
        df['rsi'] = ta.momentum.rsi(df['close'], window=14)
        df['atr'] = self.calculate_atr(df)
        df['ema_20'] = ta.trend.ema_indicator(df['close'], window=20)
        df['ema_50'] = ta.trend.ema_indicator(df['close'], window=50)
        df['ema_200'] = ta.trend.ema_indicator(df['close'], window=200)
        
        # Volume analysis for herd behavior
        df['volume_ma'] = df['volume'].rolling(window=self.volume_lookback).mean()
        df['volume_ratio'] = df['volume'] / df['volume_ma']
        
        # Body size for momentum analysis
        df['body_size'] = abs(df['close'] - df['open'])
        df['body_ma'] = df['body_size'].rolling(window=10).mean()
        
        return df
    
    def detect_fvg_with_psychology(self, df, platform, min_gap_percent=0.15):
        """
        🧠 PSYCHOLOGY-AWARE FVG DETECTION
        Enhanced with volume surge, momentum, and crowd behavior analysis
        """
        if len(df) < 10:
            return None
        
        # Look for recent FVG (last 10 candles for freshness)
        for i in range(len(df)-10, len(df)-1):
            if i < 2:
                continue
                
            c1_high = df['high'].iloc[i-2]   # Candle 1 high
            c1_low = df['low'].iloc[i-2]     # Candle 1 low
            c2_body = df['body_size'].iloc[i-1]  # Candle 2 (momentum candle)
            c2_volume = df['volume'].iloc[i-1]   # Volume of momentum candle
            c3_high = df['high'].iloc[i]     # Candle 3 high
            c3_low = df['low'].iloc[i]       # Candle 3 low
            
            current_price = df['close'].iloc[-1]
            avg_body = df['body_ma'].iloc[i-1]
            avg_volume = df['volume_ma'].iloc[i-1]
            
            # Check for bullish FVG (gap up) - institutional buying pressure
            if c3_low > c1_high:
                gap_size = c3_low - c1_high
                gap_percent = (gap_size / current_price) * 100
                
                # Enhanced validation with psychology
                volume_surge = c2_volume > (avg_volume * 2.0) if platform == "coinbase" else True
                momentum_strength = c2_body > (avg_body * 1.2)
                psychology_score = self._calculate_gap_psychology(gap_percent, volume_surge, momentum_strength, platform)
                
                if (gap_percent >= min_gap_percent and 
                    momentum_strength and
                    (volume_surge or platform == "oanda") and  # Volume surge for crypto only
                    not self.is_fvg_filled(df, i, c1_high, c3_low, 'bullish')):
                    
                    return {
                        'type': 'bullish',
                        'high': c3_low,
                        'low': c1_high,
                        'midpoint': (c1_high + c3_low) / 2,
                        'size': gap_size,
                        'candle_index': i,
                        'gap_percent': gap_percent,
                        'volume_surge': volume_surge,
                        'psychology_score': psychology_score,
                        'momentum_strength': c2_body / avg_body if avg_body > 0 else 1.0
                    }
            
            # Check for bearish FVG (gap down) - institutional selling pressure
            if c1_low > c3_high:
                gap_size = c1_low - c3_high
                gap_percent = (gap_size / current_price) * 100
                
                # Enhanced validation with psychology
                volume_surge = c2_volume > (avg_volume * 2.0) if platform == "coinbase" else True
                momentum_strength = c2_body > (avg_body * 1.2)
                psychology_score = self._calculate_gap_psychology(gap_percent, volume_surge, momentum_strength, platform)
                
                if (gap_percent >= min_gap_percent and 
                    momentum_strength and
                    (volume_surge or platform == "oanda") and
                    not self.is_fvg_filled(df, i, c3_high, c1_low, 'bearish')):
                    
                    return {
                        'type': 'bearish', 
                        'high': c1_low,
                        'low': c3_high,
                        'midpoint': (c3_high + c1_low) / 2,
                        'size': gap_size,
                        'candle_index': i,
                        'gap_percent': gap_percent,
                        'volume_surge': volume_surge,
                        'psychology_score': psychology_score,
                        'momentum_strength': c2_body / avg_body if avg_body > 0 else 1.0
                    }
        
        return None
    
    def _calculate_gap_psychology(self, gap_percent, volume_surge, momentum_strength, platform):
        """
        🧠 QUANTIFY MASS PSYCHOLOGY FROM GAP CHARACTERISTICS
        Larger gaps = higher urgency, volume surge = herd behavior, momentum = institutional flow
        """
        psychology_score = 0.0
        
        # Gap size psychology (bigger gaps = more crowd displacement)
        if gap_percent >= 0.5:
            psychology_score += 3.0  # Major psychological displacement
        elif gap_percent >= 0.25:
            psychology_score += 2.0  # Moderate displacement
        elif gap_percent >= 0.15:
            psychology_score += 1.0  # Minor displacement
        
        # Volume surge psychology (herd behavior)
        if volume_surge and platform == "coinbase":
            psychology_score += 2.0  # Strong herd participation
        
        # Momentum strength (institutional vs retail)
        if momentum_strength:
            psychology_score += 1.5  # Institutional-grade move
        
        return min(psychology_score, 6.5)  # Cap at 6.5 for psychology component
    
    def validate_entry_confluence_enhanced(self, df, fvg_data, platform, bias):
        """
        ✅ ENHANCED CONFLUENCE WITH MASS PSYCHOLOGY QUANTIFICATION
        Adapts scoring for crypto momentum vs forex mean reversion
        """
        score = 0.0
        latest_rsi = df['rsi'].iloc[-1]
        latest_close = df['close'].iloc[-1]
        fvg_type = fvg_data['type']
        
        # Add base psychology score from gap analysis
        score += fvg_data.get('psychology_score', 0)
        
        # 1. RSI herd behavior analysis (3 points max)
        if fvg_type == 'bullish':
            if latest_rsi < 35:
                score += 3.0  # Oversold + bullish FVG (herd panic exhausted)
            elif latest_rsi < 50:
                score += 1.5  # Below midline
        else:
            if latest_rsi > 65:
                score += 3.0  # Overbought + bearish FVG (herd euphoria exhausted)
            elif latest_rsi > 50:
                score += 1.5  # Above midline
        
        # 2. Platform-specific momentum vs mean reversion (2 points max)
        if platform == "coinbase":
            # Crypto: Momentum focus
            ema_alignment = self._check_crypto_momentum_alignment(df, fvg_type)
            volume_surge_boost = 0.4 if fvg_data.get('volume_surge', False) else 0
            score += ema_alignment + volume_surge_boost
        else:
            # Forex: Mean reversion focus
            mean_reversion_score = self._check_forex_mean_reversion(df, latest_rsi)
            score += mean_reversion_score
        
        # 3. FVG gap size with bias adjustment (2 points max)
        gap_percent = fvg_data['gap_percent']
        if bias == "bullish" and fvg_type == "bullish":
            gap_score = min(gap_percent * 4, 2.0)  # Boost bullish signals in bull market
        elif bias == "bearish" and fvg_type == "bearish":
            gap_score = min(gap_percent * 4, 2.0)  # Boost bearish signals in bear market
        else:
            gap_score = min(gap_percent * 3, 1.5)  # Standard scoring
        score += gap_score
        
        # 4. Price proximity to FVG (market urgency) (1.5 points max)
        distance_to_fvg = abs(latest_close - fvg_data['midpoint'])
        atr = df['atr'].iloc[-1]
        
        if distance_to_fvg <= atr * 0.3:
            score += 1.5  # Very close (immediate reaction zone)
        elif distance_to_fvg <= atr * 0.7:
            score += 1.0  # Close
        elif distance_to_fvg <= atr:
            score += 0.5  # Moderate distance
        
        # 5. Time freshness (1 point max)
        candles_since_fvg = len(df) - fvg_data['candle_index']
        if candles_since_fvg <= 3:
            score += 1.0  # Very fresh FVG
        elif candles_since_fvg <= 5:
            score += 0.5  # Fresh FVG
        
        return min(score, 10.0)  # Cap at 10.0
    
    def _check_crypto_momentum_alignment(self, df, fvg_type):
        """Check EMA alignment for crypto momentum trading"""
        latest_close = df['close'].iloc[-1]
        ema_20 = df['ema_20'].iloc[-1]
        ema_50 = df['ema_50'].iloc[-1]
        ema_200 = df['ema_200'].iloc[-1]
        
        if fvg_type == 'bullish':
            # Bullish momentum: price > EMA20 > EMA50 > EMA200
            if latest_close > ema_20 > ema_50 > ema_200:
                return 2.0  # Perfect bullish alignment
            elif latest_close > ema_20 > ema_50:
                return 1.5  # Good alignment
            elif latest_close > ema_20:
                return 1.0  # Basic alignment
        else:
            # Bearish momentum: price < EMA20 < EMA50 < EMA200
            if latest_close < ema_20 < ema_50 < ema_200:
                return 2.0  # Perfect bearish alignment
            elif latest_close < ema_20 < ema_50:
                return 1.5  # Good alignment
            elif latest_close < ema_20:
                return 1.0  # Basic alignment
        
        return 0.0
    
    def _check_forex_mean_reversion(self, df, latest_rsi):
        """Check mean reversion setup for forex"""
        # Forex tends to mean revert, look for RSI extremes
        if latest_rsi < 30 or latest_rsi > 70:
            return 2.0  # Strong mean reversion setup
        elif latest_rsi < 40 or latest_rsi > 60:
            return 1.0  # Moderate mean reversion
        else:
            return 0.3  # Neutral
    
    def detect_market_bias(self, candles_data):
        """
        🌊 DETECT OVERALL MARKET BIAS
        For session-aware bias dispatch
        """
        try:
            df = pd.DataFrame(candles_data, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
            
            if len(df) < 50:
                return "neutral"
            
            # EMA trend analysis
            df['ema_20'] = ta.trend.ema_indicator(df['close'], window=20)
            df['ema_50'] = ta.trend.ema_indicator(df['close'], window=50)
            
            latest_close = df['close'].iloc[-1]
            ema_20 = df['ema_20'].iloc[-1]
            ema_50 = df['ema_50'].iloc[-1]
            
            # Price momentum over last 20 candles
            price_change = (latest_close - df['close'].iloc[-20]) / df['close'].iloc[-20]
            
            # Determine bias
            if latest_close > ema_20 > ema_50 and price_change > 0.01:
                return "bullish"
            elif latest_close < ema_20 < ema_50 and price_change < -0.01:
                return "bearish"
            else:
                return "neutral"
                
        except Exception as e:
            log_error(f"Bias detection error: {e}", "BIAS_DETECT")
            return "neutral"
    
    def calculate_atr(self, df, period=14):
        """Calculate Average True Range"""
        high_low = df['high'] - df['low']
        high_close = np.abs(df['high'] - df['close'].shift())
        low_close = np.abs(df['low'] - df['close'].shift())
        
        true_range = np.maximum(high_low, np.maximum(high_close, low_close))
        return true_range.rolling(period).mean()
    
    def is_fvg_filled(self, df, fvg_index, low_boundary, high_boundary, fvg_type):
        """Check if FVG has been filled by subsequent candles"""
        for j in range(fvg_index + 1, len(df)):
            candle_high = df['high'].iloc[j]
            candle_low = df['low'].iloc[j]
            
            if fvg_type == 'bullish':
                # Bullish FVG filled if price goes back into gap
                if candle_low <= high_boundary:
                    return True
            else:
                # Bearish FVG filled if price goes back into gap
                if candle_high >= low_boundary:
                    return True
        
        return False

# Utility functions for external use
def calculate_position_size(capital, risk_percent, entry_price, stop_loss, streak_multiplier=1.0):
    """
    💰 ENHANCED POSITION SIZE CALCULATION
    With streak scaling and psychology-based adjustments
    """
    risk_amount = capital * (risk_percent / 100) * streak_multiplier
    stop_distance = abs(entry_price - stop_loss)
    
    if stop_distance == 0:
        return 0
    
    position_size = risk_amount / stop_distance
    return round(position_size, 6)

def generate_trade_levels_enhanced(fvg, atr_value, bias="neutral", target_rr=3.0):
    """
    🎯 ENHANCED TRADE LEVELS WITH BIAS ADJUSTMENT
    Applies bias-aware SL adjustments for harmony with market flow
    """
    from credentials import WolfpackCredentials
    creds = WolfpackCredentials()
    
    entry = fvg['midpoint']
    
    if fvg['type'] == 'bullish':
        # Base stop loss below FVG zone
        base_sl = fvg['lower'] - (atr_value * 0.5)
        
        # Bias adjustment
        if bias == "bullish":
            # Give bulls room to climb
            stop_loss = base_sl * creds.BULL_SL_ADJUSTMENT
        else:
            stop_loss = base_sl
            
        risk = entry - stop_loss
        take_profit = entry + (risk * target_rr)
    
    else:  # bearish
        # Base stop loss above FVG zone
        base_sl = fvg['upper'] + (atr_value * 0.5)
        
        # Bias adjustment
        if bias == "bearish":
            # Let bears drop without interference
            stop_loss = base_sl * creds.BEAR_SL_ADJUSTMENT
        else:
            stop_loss = base_sl
            
        risk = stop_loss - entry
        take_profit = entry - (risk * target_rr)
    
    return {
        'entry': round(entry, 5),
        'stop_loss': round(stop_loss, 5),
        'take_profit': round(take_profit, 5),
        'risk_reward': target_rr,
        'risk_amount': abs(entry - stop_loss),
        'bias_adjusted': bias != "neutral"
    }

if __name__ == "__main__":
    print("🧠 Enhanced Sniper Core loaded - Mass Psychology Quantifier ready")
    print("✅ New features:")
    print("   - Volume surge detection for crypto")
    print("   - Gap size psychology scoring")
    print("   - Platform-specific momentum vs mean reversion")
    print("   - Bias-aware SL adjustments")
    print("   - Enhanced confluence scoring")
    
    def prepare_dataframe(self, candles_data):
        """Convert OHLCV data to DataFrame with indicators"""
        df = pd.DataFrame(candles_data, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
        
        # Add technical indicators
        df['rsi'] = ta.momentum.rsi(df['close'], window=14)
        df['atr'] = self.calculate_atr(df)
        
        return df
    
    def calculate_atr(self, df, period=14):
        """Calculate Average True Range"""
        high_low = df['high'] - df['low']
        high_close = np.abs(df['high'] - df['close'].shift())
        low_close = np.abs(df['low'] - df['close'].shift())
        
        true_range = np.maximum(high_low, np.maximum(high_close, low_close))
        return true_range.rolling(period).mean()
    
    def detect_fvg(self, df, min_gap_percent=0.15):
        """
        🎯 INSTITUTIONAL FVG DETECTION
        Rules:
        1. 3-candle sequence required
        2. Gap > min_gap_percent of current price
        3. Momentum candle (middle) must be larger than average
        4. Must not be filled immediately
        """
        if len(df) < 10:
            return None
        
        # Calculate average candle body for momentum filter
        df['body_size'] = abs(df['close'] - df['open'])
        avg_body = df['body_size'].rolling(10).mean()
        
        # Look for recent FVG (last 10 candles)
        for i in range(len(df)-10, len(df)-1):
            if i < 2:
                continue
                
            c1_high = df['high'].iloc[i-2]   # Candle 1 high
            c1_low = df['low'].iloc[i-2]     # Candle 1 low
            c2_body = df['body_size'].iloc[i-1]  # Candle 2 (momentum)
            c3_high = df['high'].iloc[i]     # Candle 3 high
            c3_low = df['low'].iloc[i]       # Candle 3 low
            
            current_price = df['close'].iloc[-1]
            
            # Check for bullish FVG (gap up)
            if c3_low > c1_high:
                gap_size = c3_low - c1_high
                gap_percent = (gap_size / current_price) * 100
                
                # Validation checks
                if (gap_percent >= min_gap_percent and 
                    c2_body > avg_body.iloc[i-1] and
                    not self.is_fvg_filled(df, i, c1_high, c3_low, 'bullish')):
                    
                    return {
                        'type': 'bullish',
                        'high': c3_low,
                        'low': c1_high,
                        'midpoint': (c1_high + c3_low) / 2,
                        'size': gap_size,
                        'candle_index': i,
                        'gap_percent': gap_percent
                    }
            
            # Check for bearish FVG (gap down)
            if c1_low > c3_high:
                gap_size = c1_low - c3_high
                gap_percent = (gap_size / current_price) * 100
                
                # Validation checks
                if (gap_percent >= min_gap_percent and 
                    c2_body > avg_body.iloc[i-1] and
                    not self.is_fvg_filled(df, i, c3_high, c1_low, 'bearish')):
                    
                    return {
                        'type': 'bearish', 
                        'high': c1_low,
                        'low': c3_high,
                        'midpoint': (c3_high + c1_low) / 2,
                        'size': gap_size,
                        'candle_index': i,
                        'gap_percent': gap_percent
                    }
        
        return None
    
    def is_fvg_filled(self, df, fvg_index, low_boundary, high_boundary, fvg_type):
        """Check if FVG has been filled by subsequent candles"""
        for j in range(fvg_index + 1, len(df)):
            candle_high = df['high'].iloc[j]
            candle_low = df['low'].iloc[j]
            
            if fvg_type == 'bullish':
                # Bullish FVG filled if price goes back into gap
                if candle_low <= high_boundary:
                    return True
            else:
                # Bearish FVG filled if price goes back into gap
                if candle_high >= low_boundary:
                    return True
        
        return False
    
    def validate_entry_confluence(self, df, fvg_data):
        """
        ✅ CONFLUENCE VALIDATION
        Score signals based on multiple factors
        """
        score = 0.0
        latest_rsi = df['rsi'].iloc[-1]
        latest_close = df['close'].iloc[-1]
        fvg_type = fvg_data['type']
        
        # 1. RSI confluence (3 points max)
        if fvg_type == 'bullish':
            if latest_rsi < 35:
                score += 3.0  # Oversold + bullish FVG
            elif latest_rsi < 50:
                score += 1.5  # Below midline
        else:
            if latest_rsi > 65:
                score += 3.0  # Overbought + bearish FVG
            elif latest_rsi > 50:
                score += 1.5  # Above midline
        
        # 2. FVG gap size (2 points max)
        gap_percent = fvg_data['gap_percent']
        if gap_percent >= 0.5:
            score += 2.0  # Large gap
        elif gap_percent >= 0.25:
            score += 1.0  # Medium gap
        
        # 3. Price proximity to FVG (2 points max)
        distance_to_fvg = abs(latest_close - fvg_data['midpoint'])
        atr = df['atr'].iloc[-1]
        
        if distance_to_fvg <= atr * 0.5:
            score += 2.0  # Very close
        elif distance_to_fvg <= atr:
            score += 1.0  # Close
        
        # 4. Momentum confirmation (2 points max)
        recent_momentum = (df['close'].iloc[-1] - df['close'].iloc[-5]) / df['close'].iloc[-5]
        
        if fvg_type == 'bullish' and recent_momentum > 0.001:
            score += 2.0  # Bullish momentum
        elif fvg_type == 'bearish' and recent_momentum < -0.001:
            score += 2.0  # Bearish momentum
        
        # 5. Time since FVG formation (1 point max)
        candles_since_fvg = len(df) - fvg_data['candle_index']
        if candles_since_fvg <= 5:
            score += 1.0  # Fresh FVG
        
        return min(score, 10.0)  # Cap at 10.0

# Utility functions for external use
def calculate_atr(df, period=14):
    """Calculate Average True Range"""
    high_low = df['high'] - df['low']
    high_close = np.abs(df['high'] - df['close'].shift())
    low_close = np.abs(df['low'] - df['close'].shift())
    
    true_range = np.maximum(high_low, np.maximum(high_close, low_close))
    return true_range.rolling(period).mean()

def detect_fvg(df, min_gap_percent=0.15):
    """
    🎯 INSTITUTIONAL FVG DETECTION
    Rules:
    1. 3-candle sequence required
    2. Gap > min_gap_percent of current price
    3. Momentum candle (middle) must be larger than average
    4. Must not be filled immediately
    """
    fvg_zones = []
    
    if len(df) < 3:
        return fvg_zones
    
    # Calculate average candle body for momentum filter
    df['body_size'] = abs(df['close'] - df['open'])
    avg_body = df['body_size'].rolling(10).mean()
    
    for i in range(2, len(df)):
        c1_high = df['high'].iloc[i-2]   # Candle 1 high
        c1_low = df['low'].iloc[i-2]     # Candle 1 low
        c2_body = df['body_size'].iloc[i-1]  # Candle 2 (momentum)
        c3_high = df['high'].iloc[i]     # Candle 3 high
        c3_low = df['low'].iloc[i]       # Candle 3 low
        
        current_price = df['close'].iloc[i]
        min_gap_size = current_price * (min_gap_percent / 100)
        
        # BULLISH FVG: C3_low > C1_high (gap up)
        if c3_low > c1_high:
            gap_size = c3_low - c1_high
            
            # Validate momentum candle and gap size
            if (gap_size >= min_gap_size and 
                c2_body > avg_body.iloc[i-1] * 1.2):  # 20% larger than average
                
                fvg_zones.append({
                    'type': 'bullish',
                    'index': i,
                    'upper': c3_low,
                    'lower': c1_high,
                    'midpoint': (c3_low + c1_high) / 2,
                    'gap_size': gap_size,
                    'timestamp': df.index[i] if hasattr(df.index, 'to_pydatetime') else i,
                    'strength': gap_size / current_price * 100
                })
        
        # BEARISH FVG: C3_high < C1_low (gap down)
        elif c3_high < c1_low:
            gap_size = c1_low - c3_high
            
            # Validate momentum candle and gap size
            if (gap_size >= min_gap_size and 
                c2_body > avg_body.iloc[i-1] * 1.2):
                
                fvg_zones.append({
                    'type': 'bearish',
                    'index': i,
                    'upper': c1_low,
                    'lower': c3_high,
                    'midpoint': (c1_low + c3_high) / 2,
                    'gap_size': gap_size,
                    'timestamp': df.index[i] if hasattr(df.index, 'to_pydatetime') else i,
                    'strength': gap_size / current_price * 100
                })
    
    return fvg_zones

def calculate_fibonacci_levels(df, lookback=20):
    """
    📐 FIBONACCI RETRACEMENT LEVELS
    Uses recent swing high/low for confluence
    """
    if len(df) < lookback:
        return None
    
    recent_data = df.tail(lookback)
    swing_high = recent_data['high'].max()
    swing_low = recent_data['low'].min()
    
    diff = swing_high - swing_low
    
    return {
        'swing_high': swing_high,
        'swing_low': swing_low,
        'fib_23.6': swing_high - (diff * 0.236),
        'fib_38.2': swing_high - (diff * 0.382),
        'fib_50.0': swing_high - (diff * 0.500),
        'fib_61.8': swing_high - (diff * 0.618),
        'fib_78.6': swing_high - (diff * 0.786)
    }

def validate_entry_confluence(df, fvg, rsi_bull_min=60, rsi_bear_max=40):
    """
    ✅ ENTRY VALIDATION WITH CONFLUENCE
    Rules:
    1. FVG must be valid and fresh
    2. RSI must confirm direction
    3. Price must be above/below EMAs for trend
    4. Fibonacci golden zone confluence (optional boost)
    """
    if len(df) < 50:
        return False, 0, {}
    
    current_price = df['close'].iloc[-1]
    
    # Calculate indicators
    rsi = ta.momentum.RSIIndicator(df['close'], window=14).rsi().iloc[-1]
    ema_20 = ta.trend.EMAIndicator(df['close'], window=20).ema_indicator().iloc[-1]
    ema_50 = ta.trend.EMAIndicator(df['close'], window=50).ema_indicator().ema_indicator().iloc[-1]
    
    # Get Fibonacci levels
    fib_levels = calculate_fibonacci_levels(df)
    
    # Initialize confluence score
    confluence_score = 1.0
    entry_data = {
        'rsi': rsi,
        'ema_20': ema_20,
        'ema_50': ema_50,
        'current_price': current_price,
        'fvg_midpoint': fvg['midpoint']
    }
    
    # BULLISH VALIDATION
    if fvg['type'] == 'bullish':
        # RSI confirmation
        if rsi > rsi_bull_min:
            confluence_score += 0.5
        elif rsi < 50:
            return False, 0, entry_data
        
        # EMA trend confirmation
        if current_price > ema_20 > ema_50:
            confluence_score += 1.0
        elif current_price < ema_50:
            return False, 0, entry_data
        
        # Fibonacci confluence (golden zone 61.8-65%)
        if fib_levels:
            fib_golden_low = fib_levels['fib_61.8']
            fib_golden_high = fib_levels['fib_61.8'] * 1.05  # 5% buffer
            
            if fib_golden_low <= fvg['midpoint'] <= fib_golden_high:
                confluence_score += 1.5  # Strong confluence
    
    # BEARISH VALIDATION
    elif fvg['type'] == 'bearish':
        # RSI confirmation
        if rsi < rsi_bear_max:
            confluence_score += 0.5
        elif rsi > 50:
            return False, 0, entry_data
        
        # EMA trend confirmation
        if current_price < ema_20 < ema_50:
            confluence_score += 1.0
        elif current_price > ema_50:
            return False, 0, entry_data
        
        # Fibonacci confluence
        if fib_levels:
            fib_golden_low = fib_levels['fib_61.8'] * 0.95  # 5% buffer
            fib_golden_high = fib_levels['fib_61.8']
            
            if fib_golden_low <= fvg['midpoint'] <= fib_golden_high:
                confluence_score += 1.5
    
    # Minimum confluence score required
    min_confluence = 1.5
    is_valid = confluence_score >= min_confluence
    
    return is_valid, confluence_score, entry_data

def calculate_position_size(capital, risk_percent, entry_price, stop_loss):
    """
    💰 POSITION SIZE CALCULATION
    Fixed % risk model with streak scaling
    """
    risk_amount = capital * (risk_percent / 100)
    stop_distance = abs(entry_price - stop_loss)
    
    if stop_distance == 0:
        return 0
    
    position_size = risk_amount / stop_distance
    return round(position_size, 6)

def generate_trade_levels(fvg, atr_value, target_rr=3.0):
    """
    🎯 GENERATE ENTRY, SL, TP LEVELS
    Uses FVG zone + ATR for dynamic levels
    """
    entry = fvg['midpoint']
    
    if fvg['type'] == 'bullish':
        # Stop loss below FVG zone with ATR buffer
        stop_loss = fvg['lower'] - (atr_value * 0.5)
        # Take profit based on R:R ratio
        risk = entry - stop_loss
        take_profit = entry + (risk * target_rr)
    
    else:  # bearish
        # Stop loss above FVG zone with ATR buffer
        stop_loss = fvg['upper'] + (atr_value * 0.5)
        # Take profit based on R:R ratio
        risk = stop_loss - entry
        take_profit = entry - (risk * target_rr)
    
    return {
        'entry': round(entry, 5),
        'stop_loss': round(stop_loss, 5),
        'take_profit': round(take_profit, 5),
        'risk_reward': target_rr,
        'risk_amount': abs(entry - stop_loss)
    }

def smart_trailing_stop(entry, current_sl, current_price, atr_value, trade_type):
    """
    🔄 SMART TRAILING STOP LOGIC
    Activates after 2R profit, trails at 1R
    """
    if trade_type == 'bullish':
        profit_distance = current_price - entry
        risk_distance = entry - current_sl
        
        # Activate trailing after 2R profit
        if profit_distance >= (risk_distance * 2):
            # Trail stop to lock in 1R profit + buffer
            new_sl = entry + risk_distance + (atr_value * 0.3)
            return max(current_sl, new_sl)
    
    else:  # bearish
        profit_distance = entry - current_price
        risk_distance = current_sl - entry
        
        # Activate trailing after 2R profit
        if profit_distance >= (risk_distance * 2):
            # Trail stop to lock in 1R profit + buffer
            new_sl = entry - risk_distance - (atr_value * 0.3)
            return min(current_sl, new_sl)
    
    return current_sl

if __name__ == "__main__":
    print("🧠 Sniper Core loaded - FVG hunting logic ready")
    print("✅ Functions available:")
    print("   - detect_fvg()")
    print("   - validate_entry_confluence()")
    print("   - calculate_position_size()")
    print("   - generate_trade_levels()")
    print("   - smart_trailing_stop()")

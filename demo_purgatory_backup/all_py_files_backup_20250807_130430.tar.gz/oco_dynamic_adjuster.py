#!/usr/bin/env python3
"""
🔥 DYNAMIC OCO ADJUSTER: Wave Ride Logic
Removes TP caps on momentum, trails SL intelligently for both platforms
Quantifies when to let winners run vs lock in profits
"""

import time
import threading
from datetime import datetime
from logger import log_trade, log_error

class OCODynamicAdjuster:
    def __init__(self, coinbase, oanda, creds):
        self.coinbase = coinbase
        self.oanda = oanda
        self.creds = creds
        self.running = False
        self.monitor_thread = None
        
    def start_monitoring(self):
        """Start the wave ride monitoring in background thread"""
        if self.running:
            return
            
        self.running = True
        self.monitor_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitor_thread.start()
        log_trade("🔥 Dynamic OCO Adjuster started - Wave riding enabled", "WAVE_RIDE")
    
    def _monitoring_loop(self):
        """Main monitoring loop for wave riding"""
        while self.running:
            try:
                # Get active positions from position tracker
                from position_tracker import position_tracker
                active_positions = position_tracker.get_active_positions()
                
                for position_id, trade in active_positions.items():
                    if trade.get('status') == 'active':
                        self._process_wave_ride(position_id, trade)
                        
                time.sleep(15)  # Check every 15 seconds for wave ride adjustments
                
            except Exception as e:
                log_error(f"Wave ride monitoring error: {str(e)}", "WAVE_MONITOR")
                time.sleep(30)  # Longer pause on error
    
    def _process_wave_ride(self, position_id, trade):
        """
        🚀 PROCESS WAVE RIDE LOGIC
        1. Calculate current R:R
        2. Remove TP at wave_ride_threshold (2.5R)
        3. Trail SL intelligently based on peak tracking
        """
        try:
            current_price = self._get_current_price(trade["symbol"], trade["platform"])
            if not current_price:
                return
            
            entry_price = trade["entry_price"]
            current_sl = trade["sl_price"]
            side = trade["side"]
            
            # Calculate current R:R
            if side == "buy":
                current_profit = current_price - entry_price
                initial_risk = entry_price - current_sl
            else:
                current_profit = entry_price - current_price
                initial_risk = current_sl - entry_price
            
            if initial_risk <= 0:
                return
                
            current_rr = current_profit / initial_risk
            
            # Check if we should activate wave riding
            if current_rr >= self.creds.WAVE_RIDE_THRESHOLD and not trade.get("wave_riding", False):
                self._activate_wave_ride(position_id, trade)
            
            # If wave riding is active, manage trailing
            if trade.get("wave_riding", False):
                self._manage_trailing_stop(position_id, trade, current_price)
                
        except Exception as e:
            log_error(f"Wave ride processing error for {trade.get('symbol', 'unknown')}: {str(e)}", "WAVE_PROCESS")
    
    def _activate_wave_ride(self, position_id, trade):
        """
        🚀 ACTIVATE WAVE RIDE MODE
        Remove TP limit to let winners run unlimited
        """
        try:
            platform = trade["platform"]
            symbol = trade["symbol"]
            
            if platform == "coinbase":
                # Cancel existing TP order
                if trade.get("tp_order_id"):
                    try:
                        self.coinbase.cancel_order(trade["tp_order_id"])
                        log_trade(f"🚀 TP REMOVED: {symbol} now riding the wave", "WAVE_ACTIVATE")
                    except Exception as e:
                        log_error(f"Failed to cancel TP for {symbol}: {str(e)}", "TP_CANCEL")
                        
            else:  # OANDA
                # Remove TP via trade modification
                trade_id = trade.get("trade_id")
                if trade_id:
                    try:
                        update_data = {"takeProfit": None}  # Remove TP
                        self.oanda.trade.set_dependent_orders(
                            accountID=self.creds.OANDA_ACCOUNT_ID,
                            tradeID=trade_id,
                            data=update_data
                        )
                        log_trade(f"🚀 TP REMOVED: {symbol} OANDA wave ride activated", "WAVE_ACTIVATE")
                    except Exception as e:
                        log_error(f"Failed to remove OANDA TP for {symbol}: {str(e)}", "TP_REMOVE")
            
            # Mark as wave riding and initialize peak tracking
            trade["wave_riding"] = True
            trade["tp_order_id"] = None  # No more TP
            current_price = self._get_current_price(symbol, platform)
            
            if trade["side"] == "buy":
                trade["peak_price"] = current_price
            else:
                trade["peak_price"] = current_price
                
            # Update position tracker
            from position_tracker import update_position
            update_position(position_id, trade)
            
        except Exception as e:
            log_error(f"Wave ride activation failed: {str(e)}", "WAVE_ACTIVATE")
    
    def _manage_trailing_stop(self, position_id, trade, current_price):
        """
        🔄 INTELLIGENT TRAILING STOP MANAGEMENT
        Trail at 1.25% below peak for buys, above peak for sells
        """
        try:
            symbol = trade["symbol"]
            side = trade["side"]
            current_sl = trade["sl_price"]
            peak_price = trade.get("peak_price", trade["entry_price"])
            
            # Update peak if price moved favorably
            peak_updated = False
            if side == "buy" and current_price > peak_price:
                trade["peak_price"] = current_price
                peak_updated = True
            elif side == "sell" and current_price < peak_price:
                trade["peak_price"] = current_price
                peak_updated = True
            
            # Calculate new trailing stop based on peak
            if side == "buy":
                # Trail below peak by trail_percent
                new_sl = peak_price * (1 - self.creds.TRAIL_PERCENT)
                should_update = new_sl > current_sl  # Only move SL up
            else:
                # Trail above peak by trail_percent
                new_sl = peak_price * (1 + self.creds.TRAIL_PERCENT)
                should_update = new_sl < current_sl  # Only move SL down
            
            # Update stop loss if beneficial
            if should_update and abs(new_sl - current_sl) > abs(current_sl * 0.001):  # Min 0.1% movement
                self._update_stop_loss(position_id, trade, new_sl, peak_updated)
                
        except Exception as e:
            log_error(f"Trailing stop management error: {str(e)}", "TRAIL_MANAGE")
    
    def _update_stop_loss(self, position_id, trade, new_sl, peak_updated):
        """Update stop loss order on the platform"""
        try:
            platform = trade["platform"]
            symbol = trade["symbol"]
            old_sl = trade["sl_price"]
            
            if platform == "coinbase":
                # Cancel old SL and place new one
                if trade.get("sl_order_id"):
                    self.coinbase.cancel_order(trade["sl_order_id"])
                
                opposite_side = "sell" if trade["side"] == "buy" else "buy"
                new_sl_order = self.coinbase.create_limit_order(
                    symbol=symbol,
                    side=opposite_side,
                    amount=trade["size"],
                    price=new_sl,
                    type='stop_loss'
                )
                
                trade["sl_order_id"] = new_sl_order['id']
                
            else:  # OANDA
                # Update trade's stop loss
                trade_id = trade.get("trade_id")
                if trade_id:
                    update_data = {
                        "stopLoss": {
                            "price": str(new_sl)
                        }
                    }
                    
                    self.oanda.trade.set_dependent_orders(
                        accountID=self.creds.OANDA_ACCOUNT_ID,
                        tradeID=trade_id,
                        data=update_data
                    )
            
            # Update tracking
            trade["sl_price"] = new_sl
            
            # Update position tracker
            from position_tracker import update_position
            update_position(position_id, trade)
            
            # Log the trail update
            peak_text = " [PEAK UPDATED]" if peak_updated else ""
            log_trade(f"🔄 TRAIL {symbol} | SL: {old_sl:.6f} → {new_sl:.6f}{peak_text}", "TRAIL_UPDATE")
            
        except Exception as e:
            log_error(f"SL update failed for {trade.get('symbol', 'unknown')}: {str(e)}", "SL_UPDATE")
    
    def _get_current_price(self, symbol, platform):
        """Get current market price for symbol"""
        try:
            if platform == "coinbase":
                ticker = self.coinbase.fetch_ticker(symbol)
                return float(ticker['last'])
            else:  # OANDA
                oanda_symbol = symbol.replace('/', '_')
                pricing = self.oanda.pricing.get(
                    accountID=self.creds.OANDA_ACCOUNT_ID,
                    instruments=oanda_symbol
                )
                
                if pricing.status == 200 and 'prices' in pricing.body:
                    price_data = pricing.body['prices'][0]
                    bid = float(price_data['bids'][0]['price'])
                    ask = float(price_data['asks'][0]['price'])
                    return (bid + ask) / 2
                    
        except Exception as e:
            log_error(f"Price fetch failed for {symbol}: {str(e)}", "PRICE_FETCH")
            
        return None
    
    def stop(self):
        """Stop the wave ride monitoring"""
        self.running = False
        if self.monitor_thread and self.monitor_thread.is_alive():
            self.monitor_thread.join(timeout=10)
        log_trade("🛑 Dynamic OCO Adjuster stopped", "WAVE_STOP")

# Emergency wave ride functions for manual control
def emergency_stop_all_wave_rides(oco_adjuster):
    """Emergency function to stop all wave rides and restore TPs"""
    log_trade("🚨 EMERGENCY: Stopping all wave rides", "EMERGENCY_WAVE")
    
    try:
        from position_tracker import position_tracker
        active_positions = position_tracker.get_active_positions()
        
        for position_id, trade in active_positions.items():
            if trade.get("wave_riding", False):
                # Restore TP at current profit level
                current_price = oco_adjuster._get_current_price(trade["symbol"], trade["platform"])
                if current_price:
                    # Set TP at 80% of current profit
                    entry = trade["entry_price"]
                    if trade["side"] == "buy":
                        profit = current_price - entry
                        new_tp = entry + (profit * 0.8)
                    else:
                        profit = entry - current_price
                        new_tp = entry - (profit * 0.8)
                    
                    # Place new TP order
                    if trade["platform"] == "coinbase":
                        opposite_side = "sell" if trade["side"] == "buy" else "buy"
                        tp_order = oco_adjuster.coinbase.create_limit_order(
                            symbol=trade["symbol"],
                            side=opposite_side,
                            amount=trade["size"],
                            price=new_tp,
                            type='limit'
                        )
                        trade["tp_order_id"] = tp_order['id']
                    
                    trade["wave_riding"] = False
                    log_trade(f"🚨 Wave ride stopped for {trade['symbol']}, TP restored at {new_tp:.6f}", "EMERGENCY_RESTORE")
                    
    except Exception as e:
        log_error(f"Emergency wave ride stop failed: {str(e)}", "EMERGENCY_WAVE")

if __name__ == "__main__":
    print("🔥 Dynamic OCO Adjuster ready for wave riding")
    print("✅ Features:")
    print("   - Auto TP removal at 2.5R")
    print("   - Intelligent peak tracking")
    print("   - 1.25% trailing below/above peak")
    print("   - Emergency wave ride controls")
